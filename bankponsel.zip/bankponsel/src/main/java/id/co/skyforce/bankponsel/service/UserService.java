package id.co.skyforce.bankponsel.service;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import id.co.skyforce.bankponsel.model.UserProfile;
import id.co.skyforce.bankponsel.model.VirtualAccount;
import id.co.skyforce.bankponsel.util.HibernateUtil;

public class UserService {

	UserProfile userProfile;
	VirtualAccount virtualAccount;

	public UserProfile getProfile(Long id){
		Session session = HibernateUtil.openSession();
		userProfile = new UserProfile();
		userProfile = (UserProfile) session.get(UserProfile.class, id);
		session.close();
		return userProfile;
	}

	public List<UserProfile> listUserProfile(){
		Session session = HibernateUtil.openSession();
		Query query = session.createQuery("from UserProfile");
		List<UserProfile> list = query.list();
		session.close();
		return list;
	}
	
	public void saveOrUpdate (UserProfile user){
		Session session = HibernateUtil.openSession();
		Transaction trx = session.beginTransaction();
		session.saveOrUpdate(user);
		
		userProfile= (UserProfile) session.get(UserProfile.class, user.getId());     
		virtualAccount = new VirtualAccount();
		virtualAccount.setAccountNo(userProfile.getMobileNo());
		virtualAccount.setBalance(BigDecimal.ZERO);
		virtualAccount.setUserProfile(userProfile);
		
		session.saveOrUpdate(virtualAccount);
		trx.commit();
		session.close();
	}
	
	public void deleteUser(UserProfile user){
		Session session =HibernateUtil.openSession();
		Transaction trx =session.beginTransaction();
		session.delete(user);
		trx.commit();
		session.close();
		
	}
	
	public UserProfile getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}

	public VirtualAccount getVirtualAccount() {
		return virtualAccount;
	}

	public void setVirtualAccount(VirtualAccount virtualAccount) {
		this.virtualAccount = virtualAccount;
	}

}
