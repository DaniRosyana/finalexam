package id.co.skyforce.bankponsel.controller;

import id.co.skyforce.bankponsel.model.UserProfile;
import id.co.skyforce.bankponsel.service.UserService;

import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

@ManagedBean(name = "user")
public class UserController {

	private Long id;
	private String email;
	private String mobileNo;
	private Character userType;
	private String password;
	private String firstName;
	private String lastName;
	private Date birthDate;
	private String addressStreet;
	private String addressCity;
	private String addressPostalCode;

	UserService userService = new UserService();
	List<UserProfile> listUser;

	public UserController() {
		String userId = FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("idUser");

		if (userId != null) {
			id = Long.valueOf(userId);
			UserProfile userProfile = userService.getProfile(id);
			this.email = userProfile.getEmail();
			this.mobileNo = userProfile.getMobileNo();
			this.userType = userProfile.getUserType();
			this.password = userProfile.getPassword();
			this.firstName = userProfile.getFirstName();
			this.lastName = userProfile.getLastName();
			this.birthDate = userProfile.getBirthDate();
			this.addressStreet = userProfile.getAddressStreet();
			this.addressCity = userProfile.getAddressCity();
			this.addressPostalCode = userProfile.getAddressPostalCode();
			
		}else{
			listUser=userService.listUserProfile();
		}
	}

	public String saveOrUpdate(){
		UserProfile user = new UserProfile(email, mobileNo, userType, password, firstName, lastName, birthDate, addressStreet, addressCity, addressPostalCode);
		user.setId(id);
		userService.saveOrUpdate(user);
		listUser = getListUser();
		return "listUser";
	}
	
	public String deleteUser(){
		String userId = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("idUser");
		id = Long.valueOf(userId);
		userService = new UserService();
		UserProfile userDelete = userService.getProfile(id);
		userService.deleteUser(userDelete);
		
		listUser = getListUser();
		return "listUser";
	}
	
	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Character getUserType() {
		return userType;
	}

	public void setUserType(Character userType) {
		this.userType = userType;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public String getAddressStreet() {
		return addressStreet;
	}

	public void setAddressStreet(String addressStreet) {
		this.addressStreet = addressStreet;
	}

	public String getAddressCity() {
		return addressCity;
	}

	public void setAddressCity(String addressCity) {
		this.addressCity = addressCity;
	}

	public String getAddressPostalCode() {
		return addressPostalCode;
	}

	public void setAddressPostalCode(String addressPostalCode) {
		this.addressPostalCode = addressPostalCode;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public List<UserProfile> getListUser() {
		return listUser;
	}

	public void setListUser(List<UserProfile> listUser) {
		this.listUser = listUser;
	}
}
