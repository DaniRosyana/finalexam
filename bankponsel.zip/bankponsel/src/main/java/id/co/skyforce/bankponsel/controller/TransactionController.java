package id.co.skyforce.bankponsel.controller;

import java.math.BigDecimal;
import java.util.List;

import id.co.skyforce.bankponsel.model.Product;
import id.co.skyforce.bankponsel.model.Supplier;
import id.co.skyforce.bankponsel.model.UserProfile;
import id.co.skyforce.bankponsel.service.TransactionService;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class TransactionController {
	@ManagedProperty(value = "#{loginController}")
	private LoginController loginController;

	TransactionService transactionService = new TransactionService();
	UserProfile userProfile;
	List<Supplier> supplierList;
	List<Product> productList;
	
	private String userAccount;
	private BigDecimal amount;
	private String targetAccountNo;
	private String nameProduct;
	private String mobileNo;


	public TransactionController() {
		transactionService = new TransactionService();
		supplierList = transactionService.listSupplier();
		productList = transactionService.listproProducts();
	}

	public String deposit() {
		String deposit = transactionService.deposit(userAccount, amount);
		clear();
		return deposit;
	}

	public String withdrawl() {
		String withdrawl = transactionService.withdrawl(userAccount, amount);
		clear();
		return withdrawl;
	}

	public String transfer() {

		transactionService.transfer(loginController.userProfile.getMobileNo(),
				targetAccountNo, amount);
		clear();
		return "transfer";
	}

	public String purchase() {
		transactionService.purchase(nameProduct,loginController.userProfile.getMobileNo());

		return "purchaseItem";
	}
	
	public void clear() {
		userAccount = "";
		amount = null;
		targetAccountNo = null;
	}

	
	
	
	
	
	
	public TransactionService getTransactionService() {
		return transactionService;
	}

	public void setTransactionService(TransactionService transactionService) {
		this.transactionService = transactionService;
	}

	public String getUserAccount() {
		return userAccount;
	}

	public void setUserAccount(String userAccount) {
		this.userAccount = userAccount;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public UserProfile getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}

	public LoginController getLoginController() {
		return loginController;
	}

	public void setLoginController(LoginController loginController) {
		this.loginController = loginController;
	}

	public String getNameProduct() {
		return nameProduct;
	}

	public void setNameProduct(String nameProduct) {
		this.nameProduct = nameProduct;
	}

	public String getTargetAccountNo() {
		return targetAccountNo;
	}

	public void setTargetAccountNo(String targetAccountNo) {
		this.targetAccountNo = targetAccountNo;
	}
	public List<Supplier> getSupplierList() {
		return supplierList;
	}

	public void setSupplierList(List<Supplier> supplierList) {
		this.supplierList = supplierList;
	}

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}


}
